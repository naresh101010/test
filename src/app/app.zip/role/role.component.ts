import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { of } from "rxjs";
import { delay } from "rxjs/operators";
import { RolecreateService } from "./rolecreate.service";
import { Subscription } from "rxjs/Subscription";
import { Observable } from "rxjs";
import { Response } from "@angular/http";
import { Validators, FormControl } from "@angular/forms";
import { Router, ActivatedRoute } from '@angular/router';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { MatTableDataSource} from '@angular/material/table';


export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  read: string
  symbol: string;

}
const ELEMENT_DATA: PeriodicElement[] = [
  { position: 1, name: 'Hydrogen', weight: 1.0079, read: 'r', symbol: 'H' },
  { position: 2, name: 'Helium', weight: 4.0026, read: 'r', symbol: 'He' },
  { position: 3, name: 'Lithium', weight: 6.941, read: 'r', symbol: 'Li' },
];

export interface PopData {
  restype: string,
  ures: string
}


var attributeExclutionList = []

@Component({
  selector: 'app-home',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class HomeComponent implements OnInit {

  omFlag: boolean = false
  mobileobject: any = []
  webobject: any = []

  objectPermissionList = []

  model: any = {}
  IsCheckedr: boolean;
  IsCheckedu: boolean;
  IsCheckedc: boolean;
  IsCheckedmr: boolean;
  IsCheckedmu: boolean;
  IsCheckedmc: boolean;

  IsIndeterminate: boolean;
  LabelAlign: string;
  IsDisabled: boolean;
  IsCheckedar: boolean;
  IsCheckedau: boolean;
  IsCheckedmar: boolean;
  IsCheckedmau: boolean;



  panelOpenState = false;

  columnsToDisplay: string[] = ['subEntityName', 'create','update','read','symbol'];
  expandedElement: PeriodicElement | null;

  constructor(public router: Router, public dialog: MatDialog, public rolecreate: RolecreateService, ) {
    this.IsCheckedr = false;
    this.IsCheckedu = false;
    this.IsCheckedc = false;
    this.IsCheckedmr = false;
    this.IsCheckedmu = false;
    this.IsCheckedmc = false;
    this.IsIndeterminate = false;
    this.LabelAlign = 'after';
    this.IsDisabled = false;
    this.IsCheckedar = false;
    this.IsCheckedau = false;
    this.IsCheckedmar = false;
    this.IsCheckedmau = false;
  }

  openDialog(data: any, index: any): void {
    // console.log(data,index,'what is microservice');
    const dialogRef = this.dialog.open(DialogContentExampleDialog, {
      width: '800px',
    });
    dialogRef.afterClosed().subscribe(result => {
      debugger
      this.omFlag = true
      console.log(result);
      this.mobileobject = result.mobileobject
      this.webobject = result.webobject
      console.log('The dialog was closed');
    });
  }


  createRole() {
    debugger;
    // this.roleDto["description"] = this.model.description
    // this.roleDto["roleName"] = this.model.rolename
    console.log(this.objectpermissionlist)
    var roledata = { roleDto: { "description": this.model.description, "roleName": this.model.rolename }, objectPermissionList: this.objectpermissionlist }
    roledata.objectPermissionList.attributeExclutionList = [];
    this.rolecreate.createRole(roledata).subscribe(
      (response: any) => {
        console.log(response.message);
        this.router.navigate(['/role']);
      },
      error => {
        console.log(error);
      }
    );
  }

  OnChange($event) {
    debugger
    console.log($event.checked);
    //MatCheckboxChange {checked,MatCheckbox}
  }
  onGet() {
    this.rolecreate.getroles().subscribe((users: any) => {

      error => console.log(error);
    });
  }


  objectpermissionlist: any = []
  readMap(data, $event) {
    debugger
    this.model
    if ($event.checked == true) {
      this.IsCheckedr = true

      data["permissionId"] = 2;
      this.objectpermissionlist.push(Object.assign({},data))
    }
    else {
      for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
        if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 2) {
          this.objectPermissionList.splice(i, 1);
        }
      }
      this.IsCheckedr = false
      this.IsCheckedc = false
      this.IsCheckedu = false
      console.log(this.objectpermissionlist)
    }
  }

  createMap(data, $event) {
    if ($event.checked == true){
      this.IsCheckedc = true
      data["permissionId"] = 1;
      this.objectpermissionlist.push(Object.assign({},data))
      this.updateMap(data, $event)     
    }

    else {
      for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
        if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 1) {
          this.objectPermissionList.splice(i, 1);
        }
      }
      this.IsCheckedc = false
      console.log(this.objectpermissionlist)
    }
  }


  updateMap(data, $event) {
    debugger
    if ($event.checked == true) {
      this.IsCheckedu = true

      data["permissionId"] = 3;
      this.objectpermissionlist.push(Object.assign({},data))
      this.readMap(data, $event)

    }
    else {
      for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
        if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 3) {
          this.objectPermissionList.splice(i, 1);
        }
        this.IsCheckedu = false
        this.IsCheckedc = false
      }
      console.log(this.objectpermissionlist)
    }
  }
  mreadMap(data, $event) {
    debugger
    this.model
    console.log($event +'  jhk');
    if ($event.checked == true) {
      this.IsCheckedmr = true
      data.permissionId=3
      this.objectpermissionlist.push(Object.assign({},data))
    }
    else {
      for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
        if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 2) {
          this.objectPermissionList.splice(i, 1);
          this.IsCheckedmr = false
          this.IsCheckedmc = false
          this.IsCheckedmu = false
        }
      }

      console.log(this.objectpermissionlist)

    }
  }
  autocheck:any=0;
  mcreateMap(data, $event) {
    debugger
    console.log($event +'  jhk');
    if ($event.checked == true) {
      this.IsCheckedmc = true
      this.autocheck=1;
     
        data.permissionId= 1;
      
        this.objectpermissionlist.push(Object.assign({},data))        
      // var data1=data
      // data1.permissionId = 1;
      // this.objectpermissionlist.push(data1)
       this.mupdateMap(data, $event)
      
    }
    else {
      for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
        if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 1) {
          this.objectPermissionList.splice(i, 1);
        }
      }

      console.log(this.objectpermissionlist)
      this.IsCheckedmc = false
    }
  }
  autocheckupdate:any;
  mupdateMap(data, $event) {
    debugger
    if ($event.checked == true) {
      this.IsCheckedmu = true
      this.autocheckupdate=2;
      
      data.permissionId = 2;
      this.objectpermissionlist.push(Object.assign({},data))
      this.mreadMap(data, $event)
    }
    else {
      this.autocheck=0;
      for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
        if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 3) {
          this.objectPermissionList.splice(i, 1);
        }
      }
      this.IsCheckedmu = false
      this.IsCheckedmc = false
      console.log(this.objectpermissionlist)

    }
  }

  readAttributeExclution(data, $event) {
    debugger
    for (let ae of this.objectpermissionlist) {
      for (let attri of ae.attributeExclutionList) {
        if ($event.checked == true) {
          if (attri.attributeName == data) {
            attri.permissionId = 2;
            this.IsCheckedar = true


          }
          console.log(attri.attributeExclutionList)
        }
        else {
          if (attri.attributeName == data) {
            attri.permissionId = 0;

          }
          this.IsCheckedar = false
          this.IsCheckedau = false


        }
      }
    }
  }
  updateAttributeExclution(data, $event) {
    debugger
    for (let ae of this.objectpermissionlist) {
      for (let attri of ae.attributeExclutionList) {

        if ($event.checked == true) {

          if (attri.attributeName == data) {
            attri.permissionId = 3;
            this.IsCheckedau = true
            this.readAttributeExclution(data, $event)


          }
          console.log(attri.attributeExclutionList)
        }
        else {
          if (attri.attributeName == data) {
            attri.permissionId = 0;

          }
          this.IsCheckedau = false
        }
      }
    }
  }

  mreadAttributeExclution(data, $event) {
    debugger
    for (let ae of this.objectpermissionlist) {
      for (let attri of ae.attributeExclutionList) {
        if ($event.checked == true) {

          if (attri.attributeName == data) {
            attri.permissionId = 2;
            this.IsCheckedmar = true
          }
          console.log(attri.attributeExclutionList)
        }
        else {
          if (attri.attributeName == data) {
            attri.permissionId = 0;

          }
          this.IsCheckedmar = false
          this.IsCheckedmau = false
        }
      }
    }
  }
  mupdateAttributeExclution(data, $event) {
    debugger
    for (let ae of this.objectpermissionlist) {
      for (let attri of ae.attributeExclutionList) {

        if ($event.checked == true) {
          if (attri.attributeName == data) {
            attri.permissionId = 3;
            this.IsCheckedmau = true
            this.mreadAttributeExclution(data, $event)

          }
          console.log(attri.attributeExclutionList)
        }
        else {
          if (attri.attributeName == data) {
            attri.permissionId = 0;

          }
          this.IsCheckedmau = false
        }
      }
    }
  }

  selectObject() {
    debugger

  }
  ngOnInit() {

  }

}





@Component({
  selector: 'dialog-content-example-dialog',
  templateUrl: 'dialog-overview-example-dialog.html',
  styleUrls: ['./role.component.css']
})
export class DialogContentExampleDialog implements OnInit {
  modeld: any = {}


  constructor(
    public dialogRef: MatDialogRef<DialogContentExampleDialog>, public roleservice: RolecreateService,
    @Inject(MAT_DIALOG_DATA) public data: PopData) { }
    
  model1: any = []
  mFlag: boolean = false
  wFlag: boolean = false


  
  dataSource 
  objectList: any
  objectList2: any
  channelList=[]
  ngOnInit() {
    debugger
    this.roleservice.objectList()
      .subscribe((users: any) => {
        this.objectList = users
        for(let data of this.objectList.refernceList.channelList ){
               this.channelList.push(data)
               console.log(this.channelList,"channellist")
          }

  for(let data of this.objectList.data ){
      if (data.channelId==33){
        data.channelName="Web"

      }
      else{

        data.channelName="Mobile"

      }

  }

        this.dataSource = new MatTableDataSource(this.objectList.data);
        // this.objectList2=this.objectList
        console.log(users, 'Print users data')
        console.log(this.objectList, "displayobjectlist1234567890"),
          error => console.log(error);


      });

      // this.objectList2=this.objectList1.data
       

  }





  panelOpenState = false;

  displayedColumns: string[] = ['entityName', 'subEntityName', 'moduleName', 'select', 'channel'];
  // data1 = ELEMENT_DATA;
  userFilter: any = { branchCode: '' };

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }



  onNoClick(): void {

    this.dialogRef.close();
  }

  objectData() {
    debugger
    var a = this.model1.mobile
    // this. objectdata =  this.objectList.data.filter(function(object) {
    //  return object.subEntityName == data;
    //});
  }
  mobiledata = []
  md = 0

  mobileData(item) {
    debugger
    var objectdata = this.objectList.data.filter(function (object) {
      return object.subEntityName == item;
    })
    this.mFlag = true
    this.wFlag = false
    if (this.model1.mobile == false || this.md === 0) {
      debugger
      this.md++
      var data = objectdata.filter(function (object) {
        return object.channelId == 34;
      });
      this.mobiledata = data
    }
  }


  webdata = []
  wd = 0
  channelData(item) {
    debugger
    var objectdata = this.objectList.data.filter(function (item) {
      return item.channelId == item;
    })
    

    this.objectList.data=objectdata;

    // this.wFlag = true
    // this.mFlag = false


    // if (this.model1.web == false || this.wd === 0) {
    //   this.wd++
    //   debugger
    //   var data = objectdata.filter(function (object) {
    //     return object.channelId == 33;
    //   });
    //   this.webdata = data
    // }

  }
  mobileentity = []
  selectEntity(data, $event) {
    debugger
    if(data.channelId==34){
    if ($event.checked == true) {
      this.mobileentity.push(data)
      for (var i = this.objectList.data.length - 1; i >= 0; --i) {
        if (this.objectList.data[i].subEntityName == data.subEntityName) {
          this.objectList.data.splice(i, 1);
        }
      }
      console.log(this.mobileentity)
    }
    else {
      for (var i = this.mobileentity.length - 1; i >= 0; --i) {
        if (this.mobileentity[i].subEntityName == data.subEntityName) {
          this.mobileentity.splice(i, 1);
        }
      }
      this.objectList.data.push(data)
      console.log(this.mobileentity)
    }
  }
  else{
    if ($event.checked == true) {

      this.webentity.push(data)

      for (var i = this.objectList.data.length - 1; i >= 0; --i) {
        if (this.objectList.data[i].subEntityName == data.subEntityName) {
          this.objectList.data.splice(i, 1);
        }
      }
    }
    else {
      for (var i = this.webentity.length - 1; i >= 0; --i) {
        if (this.webentity[i].subEntityName == data.subEntityName) {
          this.webentity.splice(i, 1);
        }
      }
      this.objectList.data.push(data)
    }

  }

  }
  webentity = []

  webEntity(data, $event) {
    debugger
    this.model1.wentity
    if ($event.checked == true) {

      this.webentity.push(data)

      for (var i = this.objectList.data.length - 1; i >= 0; --i) {
        if (this.objectList.data[i].subEntityName == data.subEntityName) {
          this.objectList.data.splice(i, 1);
        }
      }
    }
    else {
      for (var i = this.webentity.length - 1; i >= 0; --i) {
        if (this.webentity[i].subEntityName == data.subEntityName) {
          this.webentity.splice(i, 1);
        }
      }
      this.objectList.data.push(data)
    }

    console.log(this.mobileentity)
  }


  filterEntity() {
    debugger
    let mobileobject = []
    let webobject = []
    mobileobject = this.mobileentity
    webobject = this.webentity
    this.dialogRef.close({ webobject, mobileobject });
    console.log(mobileobject, "mobile")
  }

  closeDialog() {

  }



  //json


  objectList1: any = {
    data: [
      {
        "moduleId": 4,
        "objectId": 1,
        "moduleName": "Credit Contract",
        "entityName": "Test",
        "subEntityName": "SE1",
        "channel": "WEB",
        "isPublic": 0,
        "permissionId": 0,
        "attributeExclutionList": [
          {
            "attributeName": "obj1attribute1",
            "createdBy": "1",
            "updatedBY": "1",
            "description": "test description",
            "permissionId": 0,
            "objectId": 1,
            "objectattribute_id": 0,
            "obj_role_perm_map_id": 0,
            "effectiveDate": "2019-09-09T12:59:35.568+0000",
            "id": 1
          },

        ],
        "status": 0
      },


      {
        "moduleId": 4,
        "objectId": 2,
        "moduleName": "Credit Contract",
        "entityName": "Test",
        "subEntityName": "SE2",
        "channel": "MOBILE",
        "isPublic": 0,
        "permissionId": 0,
        "attributeExclutionList": [
          {
            "attributeName": "obj1attribute1",
            "createdBy": "1",
            "updatedBY": "1",
            "description": "test description",
            "permissionId": 0,
            "objectId": 1,
            "objectattribute_id": 0,
            "obj_role_perm_map_id": 0,
            "effectiveDate": "2019-09-09T12:59:35.568+0000",
            "id": 1
          },

        ],
        "status": 0
      }
    ]
  }


}



