import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import 'rxjs/Rx';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Headers} from '@angular/http';
import 'rxjs/Rx';
import { AppSetting } from '../app.setting';


@Injectable({
  providedIn: 'root'
})
export class RolecreateService {

  constructor(private http: HttpClient) { }
 


  createRole(data: any) {
debugger
  const headers = { 'branchCode':'B1','journeyId':'A1', 'userId': 'User111'};
    console.log(data,"testtttt")
    return this.http.post(AppSetting.API_ENDPOINT+"secure/v1/roles", data, { headers: headers })    
    
      .map(response => {
        return response;
      }, (error: any) => { console.log(error); });
  }

  editRole(data:any) {
    const headers = { 'branchCode':'B1','journeyId':'A1', 'userId': 'User111'};

    return this.http.put(AppSetting.API_ENDPOINT+'secure/v1/roles',  data, { headers: headers })
      .map(response => {
        return response;
      }, (error: any) => { console.log(error); });
  }

  getroles() {
    debugger
    const header = new Headers();
    header.append('Content-Type', 'application/json');
   var headers =new HttpHeaders ({ 'branchCode':'B1','journeyId':'A1', 'userId': 'User1'});

    return this.http.get(AppSetting.API_ENDPOINT+'secure/v1/roles/lastUpdated/10',{headers:headers})
    .map(
      (response: Response) => {
        const data = response;
        return data;
      }
    )
    .catch(
      (error: Response) => {       
      return Observable.throw('Something went wrong');
      }
    );
}

  objectList() {
    debugger
    var headers =new HttpHeaders ({ 'branchCode':'B1','journeyId':'A1', 'userId': 'User1'});

    return this.http.get(AppSetting.API_ENDPOINT+'secure/v1/objects',{headers:headers})
    .map(
      (response: Response) => {
        const data = response;
        return data;
      }
    )
    .catch(
      (error: Response) => {       
      return Observable.throw('Something went wrong');
      }
    );
}

objectIdList(data) {
  debugger
  var headers =new HttpHeaders ({ 'branchCode':'B1','journeyId':'A1', 'userId': 'User1'});

  return this.http.get(AppSetting.API_ENDPOINT+'secure/v1/roles/'+ data+'/permissions',{headers:headers})
  .map(
    (response: Response) => {
      const data = response;
      return data;
    }
  )
  .catch(
    (error: Response) => {       
    return Observable.throw('Something went wrong');
    }
  );
}
}
