import { Component, OnInit } from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import { RolecreateService } from "./../role/rolecreate.service";
import { Router, ActivatedRoute } from '@angular/router';



export interface PeriodicElement {
  name: string;
  position: number;
  status: string;
  symbol: string;
 }
 const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Create Contract Terms & Condition', status: 'Active', symbol: 'View'},
  {position: 2, name: 'Create Contract', status: 'Active', symbol: 'View'},
  {position: 3, name: 'Create Contract', status: 'Active', symbol: 'View'},
  {position: 4, name: 'Create Contract Terms', status: 'Active', symbol: 'View'},
  {position: 5, name: 'Create Contract Branch Assignment', status: 'Active', symbol: 'View'},
  {position: 1, name: 'Create Contract Terms & Condition', status: 'Active', symbol: 'View'},
  {position: 2, name: 'Create Contract', status: 'Active', symbol: 'View'},
  {position: 3, name: 'Create Contract', status: 'Active', symbol: 'View'},
  {position: 4, name: 'Create Contract Terms', status: 'Active', symbol: 'View'},
  {position: 5, name: 'Create Contract Branch Assignment', status: 'Active', symbol: 'View'},
 ];

//  const rolelist:any  =
//    [
//     {
//       "roleId": 1,
//       "roleName": "Role1",
//       "description": "Role1 Desc",
//       "status": "0"
//     },
//     {
//       "roleId": 2,
//       "roleName": "Role2",
//       "description": "Role2 Desc",
//       "status": "0"
//     },
//     {
//       "roleId": 3,
//       "roleName": "sample role",
//       "description": "sample role",
//       "status": "0"
//     }
//   ]


var rolelist:any


@Component({
  selector: 'app-rolemanagement',
  templateUrl: './rolemanagement.component.html',
  styleUrls: ['./rolemanagement.component.css']
})
export class RolemanagementComponent implements OnInit {

  constructor(public roleservice:RolecreateService, public router:Router) { }

  ngOnInit() {
  this.onGet()
  }

  
    dataSource
  onGet() {
    debugger
    this.roleservice.getroles().subscribe((users: any) => {
         rolelist =users.data 
        this.dataSource = new MatTableDataSource(rolelist);

        console.log(rolelist,"okktest"),
      error => console.log(error);
    });
  }

//status
  status:any = [
    { lookup: "ACTIVE", value: 1 },
    { lookup: "INACTIVE", value: 0 }
  ];
  

onEdit(data){
  // this.router.navigate(['/roledetail', data.roleId,data.roleName,data.description,data.status]);
  this.router.navigate(['/roledetail', data.roleId]);
}

  displayedColumns: string[] = ['roleName', 'status', 'vewdetail'];
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
