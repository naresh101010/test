import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { RolecreateService } from './../role/rolecreate.service'
import { animate, state, style, transition, trigger } from '@angular/animations';
import { $ } from 'protractor';
import { MatTableDataSource} from '@angular/material/table';

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  read: string
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
];


export interface PopData {
  restype: string,
  ures: string
}

@Component({
  selector: 'app-rolldetail',
  templateUrl: './rolldetail.component.html',
  styleUrls: ['./rolldetail.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class RolldetailComponent implements OnInit {

  panelOpenState = false;
  columnsToDisplay: string[] = ['subEntityName', 'create', 'update', 'read', 'symbol'];
  expandedElement: PeriodicElement | null;

  //data = ELEMENT_DATA;

  model: any = {}
  IsCheckedmar: boolean;
  IsCheckedmr: boolean;
  IsCheckedmau: boolean;
  IsCheckedmu: boolean;
  IsCheckedmc: boolean;
  IsCheckedar: boolean;
  IsCheckedr: boolean;
  IsCheckedau: boolean;
  IsCheckedu: boolean;
  IsCheckedc: boolean;
  IsChecked: boolean;
  IsIndeterminate: boolean;
  LabelAlign: string;
  IsDisabled: boolean;
  mobileobject: any = []
  webobject: any = []
  constructor(private route: ActivatedRoute,
    private router: Router,
    private roleservice: RolecreateService, public dialog: MatDialog, ) {
    this.IsIndeterminate = false;
    this.LabelAlign = 'after';
    this.IsDisabled = false;
    this.IsChecked = false;
    this.IsCheckedc = false;
    this.IsCheckedr = false;
    this.IsCheckedu = false;
    this.IsCheckedau = false;
    this.IsCheckedar = false
    this.IsCheckedmc = false;
    this.IsCheckedmr = false;
    this.IsCheckedmu = false;
    this.IsCheckedmau = false;
    this.IsCheckedmar = false


  }
  roleid: any
  roleiddata: any

openDialog(data: any, index: any): void {
    // console.log(data,index,'what is microservice');
    const dialogRef = this.dialog.open(DialogContentExampleDialogEdit, {
      width: '800px',
      data: { data: data, index: index }
    });

    dialogRef.afterClosed().subscribe(result => {
      debugger
      console.log(result);

      debugger
      console.log(result);
      this.mobileobject=result.mobileobject
      this.webobject=result.webobject
      
      //   for(let data of result.mobileobject){
      // this.mobileobject.push(data)
      //   }
      
      
      //   for(let data of result.webobject){
      //     this.webobject.push(data)
      //   }
  
      console.log('The dialog was closed');
    });
  }





  //permission data
  permissionData:any = [    
     {
    permissionType: [],
    subEntityName:String
    }    
  ]
  
  webobject1
  ngOnInit() {
    debugger
    this.route.params.subscribe(params => {
      debugger
      if (params["roleId"]) {
        this.roleid = params["roleId"];
        this.model.roleName = params["roleName"]
        this.model.roleId = params["roleId"]
        this.model.description = params["description"]
        this.model.status = params["status"]


        console.log('this is edit,process is there..');
        this.roleservice.objectIdList(this.roleid)
          .subscribe((users: any) => {
            debugger
            console.log(users)
            console.log(users.data, "Hello Mr. Users welcome to project")


            for (let obj of users.data) {
              console.log(obj.roleDto.roleName, "please enter Role Name")
              this.model.roleName=obj.roleDto.roleName;


              if (obj) {
                var data = obj.objectPermissionList.filter(function (object) {
                  console.log(obj, 'print data')
                  
                  return object.channelId == 33;
                });

                for (let o of data) {
                  if (o.permissionId == 1) {
                    this.IsCheckedmc = true
                  }
                  if (o.permissionId == 2) {
                    this.IsCheckedmr = true

                  }
                  if (o.permissionId == 3) {
                    this.IsCheckedmu = true

                  }

                  for (let attri of o.attributeExclutionList) {

                    if (attri.permissionId == 3) {
                      this.IsCheckedmau = true

                    }
                    if (attri.permissionId == 2) {
                      this.IsCheckedmar = true
                    }
                  }
                
                debugger
                this.mobileobject =data
                 console.log(this.mobileobject, "mobileobject")            
                
                }
                // for (let obj of data) {              
                //   this.mobileobject.push(obj);
                //   console.log(this.mobileobject, "print MObile of data");
                // }
              }

              if (obj) {
                var data1 = obj.objectPermissionList.filter(function (object) {
                  return object.channelId == 34;
                });

               
                  for (let i = 0; i < data1.length; i++) {

                    if(data1[i].permissionType=="READ"){
                      this.IsCheckedr=true;
                    }
                    if(data1[i].permissionType=="UPDATE"){
                      this.IsCheckedu=true;
                    }
                    if(data1[i].permissionType=="CREATE"){
                      this.IsCheckedc=true;
                    }
                    this.permissionData[0].permissionType.push(data1[i].permissionType);
                    this.permissionData[0].subEntityName=data1[i].subEntityName;
                    }
                  
                  console.log(data1, "please print data1")
                  

                // for (let obj of data1) {
                //   this.webobject.push(obj);
                  //  this.webobject1=this.webobject[0]

                  // console.log(this.webobject1, "print data of data");

                
                this.webobject = data1
                console.log(this.webobject, "webobject heloo")
              }
            }

            console.log(this.roleiddata, "rolebased data"),
              error => console.log(error);
          });
      }
    });

  }
  //edit process
  objectpermissionlist: any = []

  readMap(data, $event) {
    debugger

    if (!data.permissionType) {
      if ($event.checked == true) {
        data["permissionId"] = 2;
        this.objectpermissionlist.push(data)
      }
      else {
        for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
          if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 2) {
            this.objectPermissionList.splice(i, 1);
          }
        }

        console.log(this.objectpermissionlist)
      }
    }


    if (data.permissionType) {

      if ($event.checked == true) {
        data["isAddOrRemoveOrUpdate"] = "Add",

          this.objectpermissionlist.push(data)
      }
      else {

        data["isAddOrRemoveOrUpdate"] = "Update",
          this.objectpermissionlist.push(data)

        for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
          if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 2) {
            this.objectPermissionList.splice(i, 1);
          }
        }
        console.log(this.objectpermissionlist)
      }
    }
  }

  

  createMap(data, $event) {
    debugger
    if (!data.permissionType){
      if ($event.checked == true) {
        data["permissionId"] = 1;
        this.objectpermissionlist.push(data)
      }
      else {
        for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
          if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 1) {
            this.objectPermissionList.splice(i, 1);
          }
        }
        console.log(this.objectpermissionlist)
      }
    }
    if (data.permissionType) {
      if ($event.checked == true) {        
        data["isAddOrRemoveOrUpdate"] = "Add",
          this.objectpermissionlist.push(data)
      }
      else {
        for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
          if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 1) {
            this.objectPermissionList.splice(i, 1);
          }
        }
        data["isAddOrRemoveOrUpdate"] = "Update",
        this.objectpermissionlist.push(data)
        console.log(this.objectpermissionlist)
      }
    }
  }

  updateMap(data, $event) {
    debugger
    if (!data.permissionType) {
      if ($event.checked == true) {
        data["permissionId"] = 3;
        this.objectpermissionlist.push(data)
      }
      else {
        for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
          if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 3) {
            this.objectPermissionList.splice(i, 1);
          }
        }
        console.log(this.objectpermissionlist)
      }
    }

    if (!data.permissionType) {
        if ($event.checked == true) {
          data["permissionId"] = 3;
          data["isAddOrRemoveOrUpdate"] = "Add",
            this.objectpermissionlist.push(data)
        }
      else {
        for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
          if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 1) {
            this.objectPermissionList.splice(i, 1);
          }
        }
        data["isAddOrRemoveOrUpdate"] = "Update",
        this.objectpermissionlist.push(data)
        console.log(this.objectpermissionlist)
      }
    }
  }

  mreadMap(data, $event) {
    debugger
    if (!data.permissionType) {
      if ($event.checked == true) {
        debugger;
        data["permissionId"] = 2;
        this.objectpermissionlist.push(data)
        console.log(this.objectPermissionList, )
      }
      else {
        for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
          if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 2) {
            this.objectPermissionList.splice(i, 1);
          }
        }
        console.log(this.objectpermissionlist, 'object permission list')
      }
    }


    if (data.permissionType) {

      if ($event.checked == true) {
        data["permissionId"] = 2;
        data["isAddOrRemoveOrUpdate"] = "Add",
          this.objectpermissionlist.push(data)
      }
      else {

        data["isAddOrRemoveOrUpdate"] = "Update",
          this.objectpermissionlist.push(data)

        for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
          if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 2) {
            this.objectPermissionList.splice(i, 1);
          }
        }

        console.log(this.objectpermissionlist)
      }

    }



  }

  mcreateMap(data, $event) {
    debugger

    if (!data.permissionType) {
      if ($event.checked == true) {

        data["permissionId"] = 1;
        this.objectpermissionlist.push(data)
      }
      else {
        for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
          if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 1) {
            this.objectPermissionList.splice(i, 1);
          }
        }

        console.log(this.objectpermissionlist)
      }
    }
    if (data.permissionType) {
      if ($event.checked == true) {
        data["permissionId"] = 1;
        data["isAddOrRemoveOrUpdate"] = "Add",
          this.objectpermissionlist.push(data)
      }
      else {
        for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
          if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 1) {
            this.objectPermissionList.splice(i, 1);
          }
        }
        data["isAddOrRemoveOrUpdate"] = "Update",
          this.objectpermissionlist.push(data)


        console.log(this.objectpermissionlist)
      }


    }



  }

  mupdateMap(data, $event) {
    debugger
    if (!data.permissionType) {
      if ($event.checked == true) {
        data["permissionId"] = 3;
        this.objectpermissionlist.push(data)
      }
      else {
        for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
          if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 3) {
            this.objectPermissionList.splice(i, 1);
          }
        }

        console.log(this.objectpermissionlist)
      }

    }
    if (!data.permissionType) {

      if ($event.checked == true) {
        data["permissionId"] = 3;
        data["isAddOrRemoveOrUpdate"] = "Add",
          this.objectpermissionlist.push(data)
      }
      else {
        for (var i = this.objectpermissionlist.length - 1; i >= 0; --i) {
          if (this.objectpermissionlist[i].subEntityName == data.subEntityName && this.objectpermissionlist[i].permissionId == 1) {
            this.objectPermissionList.splice(i, 1);
          }
        }
        data["isAddOrRemoveOrUpdate"] = "Update",
          this.objectpermissionlist.push(data)


        console.log(this.objectpermissionlist)
      }
    }
  }

  readAttributeExclution(data, $event) {
    debugger
    for (let ae of this.objectpermissionlist) {
      for (let attri of ae.attributeExclutionList) {
        if (!attri.permissionType) {

          if ($event.checked == true) {

            if (attri.attributeName == data) {
              attri.permissionType = 2;

            }
            console.log(attri.attributeExclutionList)
          }
          else {
            if (attri.attributeName == data) {
              attri.permissionId = 0;

            }

          }
        }
        if (attri.permissionType) {
          if ($event.checked == true) {
            attri["isAddOrRemoveOrUpdate"] = "Add"
          }
          else {
            attri["isAddOrRemoveOrUpdate"] = "Update"
          }


        }
      }
    }
  }

  updateAttributeExclution(data, $event) {
    debugger
    for (let ae of this.objectpermissionlist) {
      for (let attri of ae.attributeExclutionList) {
        if (!attri.permissionType) {

          if ($event.checked == true) {

            if (attri.attributeName == data) {
              attri.permissionType = 3;

            }
            console.log(attri.attributeExclutionList)
          }
          else {
            if (attri.attributeName == data) {
              attri.permissionId = 0;

            }

          }
        }
        if (attri.permissionType) {
          if ($event.checked == true) {
            attri["isAddOrRemoveOrUpdate"] = "Add"
          }
          else {
            attri["isAddOrRemoveOrUpdate"] = "Update"
          }


        }
      }
    }
  }

  mreadAttributeExclution(data, $event) {
    debugger
    for (let ae of this.objectpermissionlist) {
      for (let attri of ae.attributeExclutionList) {
        if (!attri.permissionType) {

          if ($event.checked == true) {

            if (attri.attributeName == data) {
              attri.permissionType = 2;

            }
            console.log(attri.attributeExclutionList)
          }
          else {
            if (attri.attributeName == data) {
              attri.permissionId = 0;

            }

          }
        }
        if (attri.permissionType) {
          if ($event.checked == true) {
            attri["isAddOrRemoveOrUpdate"] = "Add"
          }
          else {
            attri["isAddOrRemoveOrUpdate"] = "Update"
          }


        }
      }
    }
  }

  mupdateAttributeExclution(data, $event) {
    debugger
    for (let ae of this.objectpermissionlist) {
      for (let attri of ae.attributeExclutionList) {
        if (!attri.permissionType) {

          if ($event.checked == true) {

            if (attri.attributeName == data) {
              attri.permissionType = 3;

            }
            console.log(attri.attributeExclutionList)
          }
          else {
            if (attri.attributeName == data) {
              attri.permissionId = 0;

            }

          }
        }
        if (attri.permissionType) {
          if ($event.checked == true) {
            attri["isAddOrRemoveOrUpdate"] = "Add"
          }
          else {
            attri["isAddOrRemoveOrUpdate"] = "Update"
          }


        }
      }
    }
  }

  editRole() {
    debugger;
    // this.roleDto["description"] = this.model.description
    // this.roleDto["roleName"] = this.model.rolename
    this.objectpermissionlist.push({
      "attributeExclutionList": [
         {
          "addOrRemoveOrUpdate": "add",
         }
     ]
    });
    var roledata = { roleDto: { 
      "description": this.model.description, 
      "roleName": this.model.roleName,
      
      "effectiveDate": "25-11-2019",
      "expiryDate": "28-11-2019",
      "roleId": this.model.roleId,
      "status": 0,
      "updatedBy": "TEST_UPDATE_USER" }, objectPermissionList: this.objectpermissionlist }
      
    this.roleservice.editRole(roledata).subscribe(
      (response: any) => {
        console.log(response.message);

        // this.router.navigate(['/role']);

      },
      error => {
        console.log(error);
      }
    );
  }


  objectPermissionList=[]

  // objectPermissionList = [
  //   {
  //     "moduleId": 0,
  //     "objectId": 1,
  //     "entityId": 0,
  //     "moduleName": "Credit Contract",
  //     "entityName": "Test",
  //     "subEntityName": "SE1",
  //     "channel": "WEB",
  //     "id": 189,
  //     "isPublic": 0,
  //     "permissionType": "Read",
  //     "permissionId": 2,
  //     "channelId": 4,
  //     "attributeExclutionList": [
  //       {
  //         "attributeName": "obj1attribute1",
  //         "status": 1,
  //         "createdBy": "1",
  //         "permissionId": 2,
  //         "permissionExclusion": "Read",
  //         "objectId": 1,
  //         "objectattribute_id": 1,
  //         "obj_role_perm_map_id": 0,
  //         "id": 1
  //       },
  //       {
  //         "attributeName": "obj1attribute1",
  //         "status": 1,
  //         "createdBy": "1",
  //         "permissionId": 2,
  //         "permissionExclusion": "Read",
  //         "objectId": 1,
  //         "objectattribute_id": 1,
  //         "obj_role_perm_map_id": 0,
  //         "id": 3
  //       },

  //     ],
  //     "status": 1
  //   }
  // ]


}


@Component({
  selector: 'dialog-content-example-dialog',
  templateUrl: './dialog-overview-example-dialogEdit.html',
  styleUrls: ['./rolldetail.component.css']
})


export class DialogContentExampleDialogEdit implements OnInit {
  modeld: any = {}


  constructor(
    public dialogRef: MatDialogRef<DialogContentExampleDialogEdit>, public roleservice: RolecreateService,
    @Inject(MAT_DIALOG_DATA) public data: PopData) { }
    model1: any = []
    mFlag: boolean = false
    wFlag: boolean = false
  
  
    
    dataSource 
    objectList: any
    objectList2: any
    ngOnInit() {
      debugger
      this.roleservice.objectList()
        .subscribe((users: any) => {
          this.objectList = users
    for(let data of this.objectList.data ){
        if (data.channelId==33){
          data.channelName="Web"
  
        }
        else{
  
          data.channelName="Mobile"
  
        }
  
    }
  
          this.dataSource = new MatTableDataSource(this.objectList.data);
          // this.objectList2=this.objectList
          console.log(users, 'Print users data')
          console.log(this.objectList, "displayobjectlist1234567890"),
            error => console.log(error);
  
  
        });
  
        // this.objectList2=this.objectList1.data
         
  
    }
  
  
  
  
  
    panelOpenState = false;
  
    displayedColumns: string[] = ['entityName', 'subEntityName', 'moduleName', 'select', 'channel'];
    // data1 = ELEMENT_DATA;
    userFilter: any = { branchCode: '' };
  
    applyFilter(filterValue: string) {
      this.dataSource.filter = filterValue.trim().toLowerCase();
    }
  
  
  
    onNoClick(): void {
  
      this.dialogRef.close();
    }
  
    objectData() {
      debugger
      var a = this.model1.mobile
      // this. objectdata =  this.objectList.data.filter(function(object) {
      //  return object.subEntityName == data;
      //});
    }
    mobiledata = []
    md = 0
  
    mobileData(item) {
      debugger
      var objectdata = this.objectList.data.filter(function (object) {
        return object.subEntityName == item;
      })
      this.mFlag = true
      this.wFlag = false
      if (this.model1.mobile == false || this.md === 0) {
        debugger
        this.md++
        var data = objectdata.filter(function (object) {
          return object.channelId == 34;
        });
        this.mobiledata = data
      }
    }
  
  
    webdata = []
    wd = 0
    webData(item) {
      debugger
      var objectdata = this.objectList.data.filter(function (item) {
        return item.subEntityName == item;
      })
  
      this.wFlag = true
      this.mFlag = false
  
  
      if (this.model1.web == false || this.wd === 0) {
        this.wd++
        debugger
        var data = objectdata.filter(function (object) {
          return object.channelId == 33;
        });
        this.webdata = data
      }
  
    }
    mobileentity = []
    mobileEntity(data, $event) {
      debugger
      if ($event.checked == true) {
        this.mobileentity.push(data)
        for (var i = this.objectList.data.length - 1; i >= 0; --i) {
          if (this.objectList.data[i].subEntityName == data.subEntityName) {
            this.objectList.data.splice(i, 1);
          }
        }
        console.log(this.mobileentity)
      }
      else {
        for (var i = this.mobileentity.length - 1; i >= 0; --i) {
          if (this.mobileentity[i].subEntityName == data.subEntityName) {
            this.mobileentity.splice(i, 1);
          }
        }
        this.objectList.data.push(data)
        console.log(this.mobileentity)
      }
  
  
    }
    webentity = []
  
    webEntity(data, $event) {
      debugger
      this.model1.wentity
      if ($event.checked == true) {
  
        this.webentity.push(data)
  
        for (var i = this.objectList.data.length - 1; i >= 0; --i) {
          if (this.objectList.data[i].subEntityName == data.subEntityName) {
            this.objectList.data.splice(i, 1);
          }
        }
      }
      else {
        for (var i = this.webentity.length - 1; i >= 0; --i) {
          if (this.webentity[i].subEntityName == data.subEntityName) {
            this.webentity.splice(i, 1);
          }
        }
        this.objectList.data.push(data)
      }
  
      console.log(this.mobileentity)
    }
  
  
    filterEntity() {
      debugger
      let mobileobject = []
      let webobject = []
      mobileobject = this.mobileentity
      webobject = this.webentity
      this.dialogRef.close({ webobject, mobileobject });
      console.log(mobileobject, "mobile")
    }
  
    closeDialog() {
  
    }
  
  
  
    //json
  
  
    objectList1: any = {
      data: [
        {
          "moduleId": 4,
          "objectId": 1,
          "moduleName": "Credit Contract",
          "entityName": "Test",
          "subEntityName": "SE1",
          "channel": "WEB",
          "isPublic": 0,
          "permissionId": 0,
          "attributeExclutionList": [
            {
              "attributeName": "obj1attribute1",
              "createdBy": "1",
              "updatedBY": "1",
              "description": "test description",
              "permissionId": 0,
              "objectId": 1,
              "objectattribute_id": 0,
              "obj_role_perm_map_id": 0,
              "effectiveDate": "2019-09-09T12:59:35.568+0000",
              "id": 1
            },
  
          ],
          "status": 0
        },
  
  
        {
          "moduleId": 4,
          "objectId": 2,
          "moduleName": "Credit Contract",
          "entityName": "Test",
          "subEntityName": "SE2",
          "channel": "MOBILE",
          "isPublic": 0,
          "permissionId": 0,
          "attributeExclutionList": [
            {
              "attributeName": "obj1attribute1",
              "createdBy": "1",
              "updatedBY": "1",
              "description": "test description",
              "permissionId": 0,
              "objectId": 1,
              "objectattribute_id": 0,
              "obj_role_perm_map_id": 0,
              "effectiveDate": "2019-09-09T12:59:35.568+0000",
              "id": 1
            },
  
          ],
          "status": 0
        }
      ]
    }
  
  
  }
  
  